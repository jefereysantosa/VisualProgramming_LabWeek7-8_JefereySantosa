package com.classroom.vp_labweek7_8_jefereysantosa_soal1

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.Composable
import androidx.compose.ui.tooling.preview.Preview
import com.classroom.vp_labweek7_8_jefereysantosa_soal1.ui.PanPanWeatherApp.Main.PanPanWeatherAppView
import com.classroom.vp_labweek7_8_jefereysantosa_soal1.ui.theme.VP_LabWeek78_JefereySantosa_Soal1Theme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            VP_LabWeek78_JefereySantosa_Soal1Theme {
                PanPanWeatherAppView()
            }
        }
    }
}

@Preview(showBackground = true, showSystemUi = true)
@Composable
fun PanPanWeatherAppPreview() {
    VP_LabWeek78_JefereySantosa_Soal1Theme {
        PanPanWeatherAppView()
    }
}
