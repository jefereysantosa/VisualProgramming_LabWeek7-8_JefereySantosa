package com.classroom.vp_labweek7_8_jefereysantosa_soal1.ui.PanPanWeatherApp.Container

import com.classroom.vp_labweek7_8_jefereysantosa_soal1.ui.PanPanWeatherApp.Repository.WeatherRepository
import com.classroom.vp_labweek7_8_jefereysantosa_soal1.ui.PanPanWeatherApp.Service.WeatherAPI
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

object WeatherContainer {
    private const val BASE_URL = "https://api.openweathermap.org/data/2.5/"

    private val retrofit: Retrofit by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
    }

    private val weatherApiService: WeatherAPI by lazy {
        retrofit.create(WeatherAPI::class.java)
    }

    val weatherRepository: WeatherRepository by lazy {
        WeatherRepository(weatherApiService)
    }
}