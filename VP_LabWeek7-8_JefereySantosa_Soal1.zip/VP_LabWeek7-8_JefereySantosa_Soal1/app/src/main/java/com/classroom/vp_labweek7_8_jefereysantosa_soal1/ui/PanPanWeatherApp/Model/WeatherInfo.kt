package com.classroom.vp_labweek7_8_jefereysantosa_soal1.ui.PanPanWeatherApp.Model

data class WeatherInfo(
    val cityName: String,
    val temperature: String,
    val weatherCondition: String,
    val weatherDescription: String,
    val weatherIconUrl: String,
    val humidity: String,
    val windSpeed: String,
    val feelsLike: String,
    val pressure: String,
    val clouds: String,
    val sunrise: String,
    val sunset: String
)
