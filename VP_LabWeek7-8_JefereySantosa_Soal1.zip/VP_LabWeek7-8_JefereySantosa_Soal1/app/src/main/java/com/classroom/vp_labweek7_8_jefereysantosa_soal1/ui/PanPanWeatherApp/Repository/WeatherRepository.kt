package com.classroom.vp_labweek7_8_jefereysantosa_soal1.ui.PanPanWeatherApp.Repository

import com.classroom.vp_labweek7_8_jefereysantosa_soal1.ui.PanPanWeatherApp.DTO.WeatherResponse
import com.classroom.vp_labweek7_8_jefereysantosa_soal1.ui.PanPanWeatherApp.Model.WeatherInfo
import com.classroom.vp_labweek7_8_jefereysantosa_soal1.ui.PanPanWeatherApp.Service.WeatherAPI
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import kotlin.math.roundToInt

class WeatherRepository(private val weatherApiService: WeatherAPI) {

    suspend fun getWeatherByCity(cityName: String): WeatherInfo {
        val response = weatherApiService.getWeatherByCity(cityName)
        return convertDTOtoModel(response)
    }

    private fun convertDTOtoModel(dto: WeatherResponse): WeatherInfo {
        val weather = dto.weather.firstOrNull()
        val weatherCondition = weather?.main ?: "Unknown"
        val weatherDescription = weather?.description?.replaceFirstChar { it.uppercase() } ?: ""
        val iconCode = weather?.icon ?: "01d"
        val iconUrl = "https://openweathermap.org/img/wn/$iconCode@2x.png"

        val windSpeedKmh = (dto.wind.speed * 3.6).roundToInt()

        return WeatherInfo(
            cityName = dto.name,
            temperature = "${dto.main.temp.roundToInt()}",
            weatherCondition = weatherCondition,
            weatherDescription = weatherDescription,
            weatherIconUrl = iconUrl,
            humidity = "${dto.main.humidity}",
            windSpeed = "$windSpeedKmh",
            feelsLike = "${dto.main.feelsLike.roundToInt()}",
            pressure = "${dto.main.pressure}",
            clouds = "${dto.clouds.all}",
            sunrise = formatUnixTimestamp(dto.sys.sunrise, dto.timezone),
            sunset = formatUnixTimestamp(dto.sys.sunset, dto.timezone)
        )
    }

    private fun formatUnixTimestamp(unixTime: Long, timezoneOffset: Int): String {
        val netDate = Date((unixTime + timezoneOffset) * 1000L)
        val format = SimpleDateFormat("hh:mm a", Locale.getDefault()).apply {
            timeZone = TimeZone.getTimeZone("UTC")
        }
        return format.format(netDate)
    }
}