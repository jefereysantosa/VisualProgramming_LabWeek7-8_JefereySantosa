package com.classroom.vp_labweek7_8_jefereysantosa_soal1.ui.PanPanWeatherApp.Service

import com.classroom.vp_labweek7_8_jefereysantosa_soal1.ui.PanPanWeatherApp.DTO.WeatherResponse
import retrofit2.http.GET
import retrofit2.http.Query

interface WeatherAPI {
    @GET("weather")
    suspend fun getWeatherByCity(
        @Query("q") cityName: String,
        @Query("appid") apiKey: String = "79f264d285bca6f46a53ce122c13f534",
        @Query("units") units: String = "metric",
        @Query("lang") lang: String = "en"
    ): WeatherResponse
}