package com.classroom.vp_labweek7_8_jefereysantosa_soal1.ui.PanPanWeatherApp.View

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.classroom.vp_labweek7_8_jefereysantosa_soal1.R
import com.classroom.vp_labweek7_8_jefereysantosa_soal1.ui.PanPanWeatherApp.Model.WeatherInfo
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun WeatherView(weather: WeatherInfo) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = Icons.Default.LocationOn,
                contentDescription = "Location Icon",
                tint = Color.White,
                modifier = Modifier.size(22.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = weather.cityName,
                fontSize = 22.sp,
                color = Color.White
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        Text(
            text = SimpleDateFormat("MMMM dd", Locale.getDefault()).format(Date()),
            fontSize = 36.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White
        )

        Spacer(modifier = Modifier.height(4.dp))

        Text(
            text = "Updated as of " + SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date()),
            fontSize = 12.sp,
            color = Color.LightGray
        )

        Spacer(modifier = Modifier.height(32.dp))

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                AsyncImage(
                    model = ImageRequest.Builder(LocalContext.current)
                        .data(weather.weatherIconUrl)
                        .crossfade(true)
                        .build(),
                    contentDescription = weather.weatherDescription,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.size(80.dp)
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = weather.weatherCondition,
                    fontSize = 28.sp,
                    color = Color.White
                )
                Text(
                    text = "${weather.temperature}°C",
                    fontSize = 72.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }

            val pandaImage = when (weather.weatherCondition.lowercase()) {
                "clear" -> R.drawable.panda_clear
                "rain", "drizzle", "thunderstorm" -> R.drawable.panda_rain
                "clouds" -> R.drawable.panda_cloud
                else -> R.drawable.panda_clear
            }

            Image(
                painter = painterResource(pandaImage),
                contentDescription = "Panda mascot",
                modifier = Modifier.size(200.dp)
            )
        }

        Spacer(modifier = Modifier.height(32.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            InfoCard(icon = R.drawable.humidity, label = "HUMIDITY", value = "${weather.humidity}%")
            InfoCard(icon = R.drawable.wind, label = "WIND", value = "${weather.windSpeed} km/h")
            InfoCard(icon = R.drawable.feels_like, label = "FEELS LIKE", value = "${weather.feelsLike}°")
        }

        Spacer(modifier = Modifier.height(24.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            InfoCard(icon = R.drawable.rain_fall, label = "RAIN FALL", value = "0.0 mm")
            InfoCard(icon = R.drawable.pressure, label = "PRESSURE", value = "${weather.pressure}hPa")
            InfoCard(icon = R.drawable.clouds, label = "CLOUDS", value = "${weather.clouds}%")
        }

        Spacer(modifier = Modifier.height(32.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceAround
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Image(
                    painter = painterResource(id = R.drawable.sunrise),
                    contentDescription = "Sunrise",
                    modifier = Modifier.size(52.dp)
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(text = "SUNRISE", fontSize = 16.sp, color = Color.White)
                Spacer(modifier = Modifier.height(4.dp))
                Text(text = weather.sunrise, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color.White)
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Image(
                    painter = painterResource(id = R.drawable.sunset),
                    contentDescription = "Sunset",
                    modifier = Modifier.size(52.dp)
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(text = "SUNSET", fontSize = 16.sp, color = Color.White)
                Spacer(modifier = Modifier.height(4.dp))
                Text(text = weather.sunset, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color.White)
            }
        }
        Spacer(modifier = Modifier.height(16.dp))
    }
}

@Composable
fun InfoCard(icon: Int, label: String, value: String) {
    Card(
        modifier = Modifier.size(110.dp, 130.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.2f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(PaddingValues(vertical = 12.dp, horizontal = 4.dp)),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceAround
        ) {
            Image(
                painter = painterResource(id = icon),
                contentDescription = label,
                modifier = Modifier.size(40.dp)
            )
            Text(text = label, fontSize = 13.sp, color = Color.White)
            Text(text = value, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color.White)
        }
    }
}

@Preview(showBackground = true, showSystemUi = true)
@Composable
private fun WeatherViewPreview() {
    WeatherView(
        weather = WeatherInfo(
            cityName = "Cebu",
            temperature = "32",
            weatherCondition = "Clouds",
            weatherDescription = "broken clouds",
            weatherIconUrl = "https://openweathermap.org/img/wn/04d@2x.png",
            humidity = "53",
            windSpeed = "3",
            feelsLike = "35",
            pressure = "1007",
            clouds = "75",
            sunrise = "05:22 AM",
            sunset = "05:29 PM"
        )
    )
}
