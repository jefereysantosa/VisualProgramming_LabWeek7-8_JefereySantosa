package com.classroom.vp_labweek7_8_jefereysantosa_soal1.ui.PanPanWeatherApp.ViewModel

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.classroom.vp_labweek7_8_jefereysantosa_soal1.ui.PanPanWeatherApp.Container.WeatherContainer
import com.classroom.vp_labweek7_8_jefereysantosa_soal1.ui.PanPanWeatherApp.Model.WeatherInfo
import kotlinx.coroutines.launch

sealed class WeatherUIState {
    object Idle : WeatherUIState()
    object Loading : WeatherUIState()
    data class Success(val weather: WeatherInfo) : WeatherUIState()
    data class Error(val message: String) : WeatherUIState()
}

class WeatherViewModel : ViewModel() {
    private val repository = WeatherContainer.weatherRepository

    var uiState: WeatherUIState by mutableStateOf(WeatherUIState.Idle)
        private set

    var searchQuery by mutableStateOf("")
        private set

    fun updateSearchQuery(query: String) {
        searchQuery = query
    }

    fun searchWeather() {
        if (searchQuery.isBlank()) {
            uiState = WeatherUIState.Error("Please enter a city name")
            return
        }

        viewModelScope.launch {
            uiState = WeatherUIState.Loading
            try {
                val weather = repository.getWeatherByCity(searchQuery)
                uiState = WeatherUIState.Success(weather)
            } catch (e: Exception) {
                uiState = WeatherUIState.Error(
                    e.message ?: "Failed to fetch weather data"
                )
            }
        }
    }
}